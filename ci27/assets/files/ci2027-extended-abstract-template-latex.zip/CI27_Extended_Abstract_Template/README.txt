Readme for BLG Authoring Template
=================================

The first release CUP-JNL-BLG.cls (version 0.1) and latex template
includes following files: (The current release is version 0.1)

********************************** Files **********************************

README.txt               - This file.

CUP-JNL-BLG.cls - The CUP Authoring template class file.

User-manual.pdf          - The user manual for how to work with templates.

Sample.pdf               - A sample output of Authoring template.

Sample.tex               - The main file of latex template.

Sample.bbl               - A sample reference output file.

Sample-Refs.bib          - A sample bibtex file.

fig.eps                  - A sample image.

***************************************************************************
